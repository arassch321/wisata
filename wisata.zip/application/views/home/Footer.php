	<script src="<?=base_url()?>assets/home_assets/js/jquery-3.3.1.min.js"></script>
	<script src="<?=base_url()?>assets/home_assets/js/jquery-migrate-3.0.1.min.js"></script>
	<script src="<?=base_url()?>assets/home_assets/js/jquery-ui.js"></script>
	<script src="<?=base_url()?>assets/home_assets/js/popper.min.js"></script>
	<script src="<?=base_url()?>assets/home_assets/js/bootstrap.min.js"></script>
	<script src="<?=base_url()?>assets/home_assets/js/owl.carousel.min.js"></script>
	<script src="<?=base_url()?>assets/home_assets/js/jquery.stellar.min.js"></script>
	<script src="<?=base_url()?>assets/home_assets/js/jquery.countdown.min.js"></script>
	<script src="<?=base_url()?>assets/home_assets/js/jquery.magnific-popup.min.js"></script>
	<script src="<?=base_url()?>assets/home_assets/js/bootstrap-datepicker.min.js"></script>
	<script src="<?=base_url()?>assets/home_assets/js/aos.js"></script>
	<script src="<?=base_url()?>assets/home_assets/js/main.js"></script>
</body>
</html>